from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
import sqlite3
import csv
import io
import zipfile
from xml.sax.saxutils import escape as xml_escape

HOST = "127.0.0.1"
PORT = 4173
BASE_DIR = Path(__file__).parent
DATABASE_PATH = BASE_DIR / "brujula.db"
ADMIN_PASSWORD = "viajes2026"
VALID_DOCUMENT_TYPES = {"DNI", "Pasaporte", "CE"}


def initialize_database():
    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        connection.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('admin_password', ?)", (ADMIN_PASSWORD,))
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                document_type TEXT NOT NULL CHECK(document_type IN ('DNI', 'Pasaporte', 'CE')),
                document_number TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(document_type, document_number)
            )
            """
        )
        client_columns = {row[1] for row in connection.execute("PRAGMA table_info(clients)").fetchall()}
        if "route" not in client_columns:
            connection.execute("ALTER TABLE clients ADD COLUMN route TEXT NOT NULL DEFAULT 'Sin ruta seleccionada'")
        if "route_price" not in client_columns:
            connection.execute("ALTER TABLE clients ADD COLUMN route_price INTEGER NOT NULL DEFAULT 0")
        connection.commit()


def get_admin_password():
    with sqlite3.connect(DATABASE_PATH) as connection:
        row = connection.execute("SELECT value FROM settings WHERE key = 'admin_password'").fetchone()
    return row[0] if row else ADMIN_PASSWORD


def update_admin_password(new_password):
    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.execute("UPDATE settings SET value = ? WHERE key = 'admin_password'", (new_password,))
        connection.commit()


def read_json_body(handler):
    content_length = int(handler.headers.get("Content-Length", "0"))
    raw_body = handler.rfile.read(content_length)
    return json.loads(raw_body.decode("utf-8"))


def send_json(handler, status_code, payload):
    response = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status_code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(response)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(response)


def get_clients():
    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.row_factory = sqlite3.Row
        return [dict(row) for row in connection.execute(
            "SELECT full_name, document_type, document_number, email, phone, route, route_price, created_at "
            "FROM clients ORDER BY id DESC"
        ).fetchall()]


def make_xlsx(clients):
    headers = ["Nombre completo", "Tipo de documento", "Número de documento", "Correo electrónico", "Teléfono", "Ruta", "Precio", "Fecha de registro"]
    rows = [headers] + [[client[key] for key in ("full_name", "document_type", "document_number", "email", "phone", "route", "route_price", "created_at")] for client in clients]
    sheet_rows = []
    for row_number, row in enumerate(rows, 1):
        cells = []
        for column_number, value in enumerate(row, 1):
            column = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[column_number - 1]
            cells.append(f'<c r="{column}{row_number}" t="inlineStr"><is><t>{xml_escape(str(value))}</t></is></c>')
        sheet_rows.append(f'<row r="{row_number}">' + "".join(cells) + "</row>")
    files = {
        "[Content_Types].xml": '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
        "_rels/.rels": '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
        "xl/_rels/workbook.xml.rels": '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>',
        "xl/workbook.xml": '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Clientes" sheetId="1" r:id="rId1"/></sheets></workbook>',
        "xl/worksheets/sheet1.xml": '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>' + "".join(sheet_rows) + "</sheetData></worksheet>"
    }
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as workbook:
        for filename, content in files.items():
            workbook.writestr(filename, content)
    return output.getvalue()


class BrújulaHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/api/clients/export"):
            if not self.is_authenticated():
                send_json(self, 401, {"error": "No autorizado"})
                return
            clients = get_clients()
            export_format = "xlsx" if "format=xlsx" in self.path else "csv"
            if export_format == "xlsx":
                response = make_xlsx(clients)
                content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                filename = "clientes-brujula.xlsx"
            else:
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(["Nombre completo", "Tipo de documento", "Número de documento", "Correo electrónico", "Teléfono", "Ruta", "Precio", "Fecha de registro"])
                for client in clients:
                    writer.writerow([client[key] for key in ("full_name", "document_type", "document_number", "email", "phone", "route", "route_price", "created_at")])
                response = output.getvalue().encode("utf-8-sig")
                content_type = "text/csv; charset=utf-8"
                filename = "clientes-brujula.csv"
            self.send_binary(response, content_type, filename)
            return
        if self.path == "/api/clients":
            if not self.is_authenticated():
                send_json(self, 401, {"error": "No autorizado"})
                return
            with sqlite3.connect(DATABASE_PATH) as connection:
                connection.row_factory = sqlite3.Row
                rows = connection.execute(
                    "SELECT id, full_name, document_type, document_number, email, phone, route, route_price, created_at "
                    "FROM clients ORDER BY id DESC"
                ).fetchall()
            send_json(self, 200, {"clients": [dict(row) for row in rows]})
            return
        super().do_GET()

    def do_POST(self):
        if self.path == "/api/auth":
            try:
                payload = read_json_body(self)
            except (json.JSONDecodeError, UnicodeDecodeError):
                send_json(self, 400, {"error": "Solicitud no válida"})
                return
            if payload.get("password") != get_admin_password():
                send_json(self, 401, {"error": "Contraseña incorrecta"})
                return
            send_json(self, 200, {"message": "Acceso autorizado"})
            return
        if self.path == "/api/change-password":
            if not self.is_authenticated():
                send_json(self, 401, {"error": "La contraseña actual no es correcta"})
                return
            try:
                payload = read_json_body(self)
            except (json.JSONDecodeError, UnicodeDecodeError):
                send_json(self, 400, {"error": "Solicitud no válida"})
                return
            new_password = str(payload.get("newPassword", ""))
            if len(new_password) < 8:
                send_json(self, 400, {"error": "La nueva contraseña debe tener al menos 8 caracteres"})
                return
            update_admin_password(new_password)
            send_json(self, 200, {"message": "Contraseña actualizada"})
            return
        if self.path != "/api/clients":
            send_json(self, 404, {"error": "Ruta no encontrada"})
            return
        try:
            payload = read_json_body(self)
        except (json.JSONDecodeError, UnicodeDecodeError):
            send_json(self, 400, {"error": "El cuerpo de la solicitud no es válido"})
            return

        full_name = str(payload.get("fullName", "")).strip()
        document_type = str(payload.get("documentType", "")).strip()
        document_number = str(payload.get("documentNumber", "")).strip()
        email = str(payload.get("email", "")).strip()
        phone = str(payload.get("phone", "")).strip()
        route = str(payload.get("route", "")).strip()
        route_price = int(payload.get("routePrice", 0) or 0)

        if not all((full_name, document_type, document_number, email, phone, route)) or route_price <= 0:
            send_json(self, 400, {"error": "Completa todos los campos"})
            return
        if document_type not in VALID_DOCUMENT_TYPES:
            send_json(self, 400, {"error": "Tipo de documento no válido"})
            return

        try:
            with sqlite3.connect(DATABASE_PATH) as connection:
                cursor = connection.execute(
                    "INSERT INTO clients (full_name, document_type, document_number, email, phone, route, route_price) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (full_name, document_type, document_number, email, phone, route, route_price),
                )
                connection.commit()
                client_id = cursor.lastrowid
        except sqlite3.IntegrityError:
            send_json(self, 409, {"error": "Ese documento ya está registrado"})
            return

        send_json(self, 201, {"id": client_id, "message": "Cliente registrado correctamente"})

    def is_authenticated(self):
        return self.headers.get("X-Admin-Password") == get_admin_password()

    def send_binary(self, response, content_type, filename):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def log_message(self, format_string, *args):
        print(f"{self.address_string()} - {format_string % args}")


if __name__ == "__main__":
    initialize_database()
    server = ThreadingHTTPServer((HOST, PORT), BrújulaHandler)
    print(f"Brújula activa en http://localhost:{PORT}")
    print(f"Base de datos: {DATABASE_PATH}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido")
    finally:
        server.server_close()
