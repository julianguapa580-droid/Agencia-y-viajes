const DEFAULT_ROUTES = [
  { id: 1, title: "Bali esencial", location: "Indonesia", duration: "10 días / 9 noches", price: 1490, tag: "Más elegido", image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=900&q=85" },
  { id: 2, title: "Lisboa lenta", location: "Portugal", duration: "5 días / 4 noches", price: 690, tag: "Escapada", image: "https://images.unsplash.com/photo-1555881400-74d7acaacd8b?auto=format&fit=crop&w=900&q=85" },
  { id: 3, title: "Patagonia libre", location: "Argentina", duration: "12 días / 11 noches", price: 2190, tag: "Aventura", image: "https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&w=900&q=85" },
  { id: 4, title: "Tumbes tropical", location: "Tumbes, Perú", duration: "4 días / 3 noches", price: 520, tag: "Playa", image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=85" },
  { id: 5, title: "Piura de sol", location: "Piura, Perú", duration: "4 días / 3 noches", price: 460, tag: "Norte peruano", image: "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=85" },
  { id: 6, title: "Chiclayo ancestral", location: "Chiclayo, Perú", duration: "3 días / 2 noches", price: 390, tag: "Cultura", image: "https://images.unsplash.com/photo-1531685250784-7569952593d2?auto=format&fit=crop&w=900&q=85" },
  { id: 7, title: "Trujillo colonial", location: "Trujillo, Perú", duration: "3 días / 2 noches", price: 420, tag: "Historia", image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=900&q=85" },
  { id: 8, title: "Chimbote costero", location: "Chimbote, Perú", duration: "3 días / 2 noches", price: 360, tag: "Mar y sabor", image: "https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?auto=format&fit=crop&w=900&q=85" },
  { id: 9, title: "Lima urbana", location: "Lima, Perú", duration: "3 días / 2 noches", price: 480, tag: "Ciudad", image: "https://images.unsplash.com/photo-1531968455001-5c5272a41129?auto=format&fit=crop&w=900&q=85" }
];

const STORAGE_KEY = "brujula-routes";
let adminPassword = localStorage.getItem("brujula-admin-password") || "";
let routes = loadRoutes();
let clients = [];

const routeGrid = document.querySelector("#route-grid");
const adminRouteList = document.querySelector("#admin-route-list");
const emptyState = document.querySelector("#empty-state");
const adminModal = document.querySelector("#admin-modal");
const adminLogin = document.querySelector("#admin-login");
const adminDashboard = document.querySelector("#admin-dashboard");
const loginForm = document.querySelector("#login-form");
const loginError = document.querySelector("#login-error");
const toast = document.querySelector("#toast");
const routeForm = document.querySelector("#route-form");
const clientList = document.querySelector("#client-list");
const publicClientForm = document.querySelector("#public-client-form");
const publicClientError = document.querySelector("#public-client-error");
const publicClientRoute = document.querySelector("#public-client-route");
const publicClientRoutePrice = document.querySelector("#public-client-route-price");
let editingRouteId = null;

document.querySelector("#public-registration-date").value = new Intl.DateTimeFormat("es-PE", { dateStyle: "long" }).format(new Date());
publicClientRoute.addEventListener("change", () => {
  const selectedOption = publicClientRoute.options[publicClientRoute.selectedIndex];
  const selectedPrice = selectedOption?.dataset.price;
  publicClientRoutePrice.value = selectedPrice ? formatPrice(Number(selectedPrice)) : "";
});

function loadRoutes() {
  try {
    const savedRoutes = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!Array.isArray(savedRoutes)) return DEFAULT_ROUTES;
    const savedIds = new Set(savedRoutes.map((route) => route.id));
    const missingDefaults = DEFAULT_ROUTES.filter((route) => !savedIds.has(route.id));
    return [...savedRoutes, ...missingDefaults];
  } catch (error) {
    return DEFAULT_ROUTES;
  }
}

function saveRoutes() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(routes));
}

function formatPrice(price) {
  return "S/ " + new Intl.NumberFormat("es-PE", { maximumFractionDigits: 0 }).format(price);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;" }[character]));
}

function renderPublicRoutes() {
  routeGrid.innerHTML = routes.map((route, index) => `
    <article class="route-card" style="background-image: url('${escapeHtml(route.image)}')">
      <span class="route-index">0${index + 1}</span>
      <span class="route-tag">${escapeHtml(route.tag)}</span>
      <h3>${escapeHtml(route.title)}</h3>
      <div class="route-meta"><span>${escapeHtml(route.location)} · ${escapeHtml(route.duration)}</span><span class="route-price">Desde ${formatPrice(route.price)}</span></div>
    </article>
  `).join("");
  emptyState.hidden = routes.length > 0;
  publicClientRoute.innerHTML = '<option value="">Selecciona una ruta</option>' + routes.map((route) => `<option value="${escapeHtml(route.title)}" data-price="${route.price}">${escapeHtml(route.title)} · ${escapeHtml(route.location)} · ${formatPrice(route.price)}</option>`).join("");
}

function renderAdminRoutes() {
  adminRouteList.innerHTML = routes.length ? routes.map((route) => `
    <div class="admin-route-item">
      <div class="admin-route-thumb" style="background-image: url('${escapeHtml(route.image)}')"></div>
      <div><h4>${escapeHtml(route.title)}</h4><p>${escapeHtml(route.location)} · ${formatPrice(route.price)}</p></div>
      <div class="route-actions"><button class="edit-button" type="button" data-action="edit" data-id="${route.id}">Editar</button><button class="delete-button" type="button" data-action="delete" data-id="${route.id}">Eliminar</button></div>
    </div>
  `).join("") : '<p class="empty-state">Añade tu primera ruta para verla aquí.</p>';
  document.querySelector("#route-count").textContent = routes.length;
  document.querySelector("#lowest-price").textContent = routes.length ? formatPrice(Math.min(...routes.map((route) => route.price))) : "0 €";
}

function renderAll() {
  renderPublicRoutes();
  renderAdminRoutes();
}

function renderClients() {
  document.querySelector("#client-count").textContent = `${clients.length} cliente${clients.length === 1 ? "" : "s"}`;
  clientList.innerHTML = clients.length ? clients.map((client) => `
    <div class="client-row">
      <div><strong>${escapeHtml(client.full_name)}</strong><span>${escapeHtml(client.email)}</span></div>
      <div><span class="client-document">${escapeHtml(client.document_type)} · ${escapeHtml(client.document_number)}</span></div>
      <div><span>${escapeHtml(client.route)} · ${formatPrice(client.route_price)}</span></div>
      <div><span>${escapeHtml(client.phone)}</span></div>
      <div><span>Registrado ${new Date(client.created_at.replace(" ", "T") + "Z").toLocaleDateString("es-PE")}</span></div>
    </div>
  `).join("") : '<p class="empty-state">Todavía no hay clientes registrados.</p>';
}

async function loadClients() {
  try {
    const response = await fetch("/api/clients", { headers: { "X-Admin-Password": adminPassword } });
    if (!response.ok) throw new Error("No se pudieron cargar los clientes");
    const data = await response.json();
    clients = data.clients;
    renderClients();
  } catch (error) {
    clientList.innerHTML = '<p class="empty-state">No se pudo conectar con la base de datos.</p>';
    showToast("No se pudo conectar con la base de datos.");
  }
}

async function exportClients(format) {
  try {
    const response = await fetch(`/api/clients/export?format=${format}`, { headers: { "X-Admin-Password": adminPassword } });
    if (!response.ok) throw new Error("No se pudo generar el archivo");
    const blob = await response.blob();
    const downloadUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = downloadUrl;
    link.download = format === "xlsx" ? "clientes-brujula.xlsx" : "clientes-brujula.csv";
    link.click();
    URL.revokeObjectURL(downloadUrl);
    showToast(`Archivo ${format.toUpperCase()} descargado.`);
  } catch (error) {
    showToast(error.message);
  }
}

function openAdmin() {
  adminModal.hidden = false;
  adminLogin.hidden = false;
  adminDashboard.hidden = true;
  document.querySelector("#login-form").hidden = false;
  document.querySelector("#show-password-form").hidden = false;
  document.querySelector("#change-password-form").hidden = true;
  loginError.textContent = "";
  document.querySelector("#admin-password").value = "";
  setTimeout(() => document.querySelector("#admin-password").focus(), 50);
}

function closeAdmin() {
  adminModal.hidden = true;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2600);
}

function openRouteForm(route = null) {
  editingRouteId = route ? route.id : null;
  document.querySelector("#route-form-title").textContent = route ? "Editar ruta" : "Nueva ruta";
  document.querySelector("#route-title-input").value = route?.title || "";
  document.querySelector("#route-location-input").value = route?.location || "";
  document.querySelector("#route-duration-input").value = route?.duration || "";
  document.querySelector("#route-price-input").value = route?.price || "";
  document.querySelector("#route-tag-input").value = route?.tag || "Nueva ruta";
  document.querySelector("#route-image-input").value = route?.image || DEFAULT_ROUTES[0].image;
  routeForm.hidden = false;
  document.querySelector("#route-title-input").focus();
}

function closeRouteForm() {
  editingRouteId = null;
  routeForm.hidden = true;
  routeForm.reset();
}

renderAll();

document.querySelectorAll(".admin-open").forEach((button) => button.addEventListener("click", openAdmin));
document.querySelector(".modal-close").addEventListener("click", closeAdmin);
adminModal.addEventListener("click", (event) => { if (event.target === adminModal) closeAdmin(); });
document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !adminModal.hidden) closeAdmin(); });

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const password = document.querySelector("#admin-password").value;
  fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password }) })
    .then(async (response) => {
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Contraseña incorrecta");
      adminPassword = password;
      localStorage.setItem("brujula-admin-password", adminPassword);
      adminLogin.hidden = true;
      adminDashboard.hidden = false;
      renderAdminRoutes();
      loadClients();
    })
    .catch((error) => { loginError.textContent = error.message; });
});

document.querySelector("#show-password-form").addEventListener("click", () => {
  document.querySelector("#login-form").hidden = true;
  document.querySelector("#show-password-form").hidden = true;
  document.querySelector("#change-password-form").hidden = false;
});

document.querySelector("#cancel-password-form").addEventListener("click", () => {
  document.querySelector("#change-password-form").hidden = true;
  document.querySelector("#login-form").hidden = false;
  document.querySelector("#show-password-form").hidden = false;
  document.querySelector("#password-error").textContent = "";
});

document.querySelector("#change-password-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const errorElement = document.querySelector("#password-error");
  const currentPassword = document.querySelector("#current-password").value;
  const newPassword = document.querySelector("#new-password").value;
  const confirmPassword = document.querySelector("#confirm-password").value;
  if (newPassword !== confirmPassword) {
    errorElement.textContent = "Las nuevas contraseñas no coinciden.";
    return;
  }
  try {
    const response = await fetch("/api/change-password", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Admin-Password": currentPassword },
      body: JSON.stringify({ newPassword })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "No se pudo cambiar la contraseña");
    adminPassword = newPassword;
    localStorage.setItem("brujula-admin-password", adminPassword);
    document.querySelector("#change-password-form").reset();
    document.querySelector("#change-password-form").hidden = true;
    document.querySelector("#login-form").hidden = false;
    document.querySelector("#show-password-form").hidden = false;
    showToast("Contraseña cambiada correctamente.");
  } catch (error) {
    errorElement.textContent = error.message;
  }
});

document.querySelector("#logout-button").addEventListener("click", () => {
  adminDashboard.hidden = true;
  adminLogin.hidden = false;
  document.querySelector("#admin-password").value = "";
  showToast("Sesión cerrada correctamente.");
});

document.querySelector("#export-csv-button").addEventListener("click", () => exportClients("csv"));
document.querySelector("#export-xlsx-button").addEventListener("click", () => exportClients("xlsx"));

document.querySelector("#add-route-button").addEventListener("click", () => {
  openRouteForm();
});

document.querySelector("#cancel-route-button").addEventListener("click", closeRouteForm);

routeForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const details = {
    title: document.querySelector("#route-title-input").value.trim(),
    location: document.querySelector("#route-location-input").value.trim(),
    duration: document.querySelector("#route-duration-input").value.trim(),
    price: Number(document.querySelector("#route-price-input").value),
    tag: document.querySelector("#route-tag-input").value.trim(),
    image: document.querySelector("#route-image-input").value.trim()
  };
  if (!details.title || !details.location || !details.duration || !details.tag || !details.image || !Number.isFinite(details.price) || details.price <= 0) {
    showToast("Completa todos los campos con datos válidos.");
    return;
  }
  if (editingRouteId) {
    const routeIndex = routes.findIndex((route) => route.id === editingRouteId);
    routes[routeIndex] = { ...routes[routeIndex], ...details };
    showToast("Ruta actualizada.");
  } else {
    routes.push({ ...details, id: Date.now() });
    showToast("Ruta añadida al catálogo.");
  }
  saveRoutes();
  renderAll();
  closeRouteForm();
});

publicClientForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  publicClientError.textContent = "";
  const payload = {
    fullName: document.querySelector("#public-client-name").value.trim(),
    documentType: document.querySelector("#public-document-type").value,
    documentNumber: document.querySelector("#public-document-number").value.trim(),
    email: document.querySelector("#public-client-email").value.trim(),
    phone: document.querySelector("#public-client-phone").value.trim()
    ,route: document.querySelector("#public-client-route").value,
    routePrice: Number(document.querySelector("#public-client-route option:checked").dataset.price || 0)
  };
  try {
    const response = await fetch("/api/clients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "No se pudo registrar tus datos");
    publicClientForm.reset();
    showToast("Datos registrados. Te contactaremos pronto.");
  } catch (error) {
    publicClientError.textContent = error.message;
  }
});

adminRouteList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const routeId = Number(button.dataset.id);
  const routeIndex = routes.findIndex((route) => route.id === routeId);
  if (routeIndex < 0) return;
  if (button.dataset.action === "delete") {
    if (!window.confirm(`¿Eliminar la ruta ${routes[routeIndex].title}?`)) return;
    routes.splice(routeIndex, 1);
    saveRoutes();
    renderAll();
    showToast("Ruta eliminada.");
    return;
  }
  openRouteForm(routes[routeIndex]);
});
