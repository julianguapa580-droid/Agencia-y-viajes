import sqlite3
from datetime import date
from pathlib import Path

import openpyxl
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

APP_DIR = Path(__file__).resolve().parent
DB_FILE = APP_DIR / "biblioteca.db"


def create_tables(conn):
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS libros (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            autor TEXT NOT NULL,
            categoria TEXT NOT NULL,
            isbn TEXT,
            disponible INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS lectores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            telefono TEXT,
            correo TEXT
        );
        CREATE TABLE IF NOT EXISTS prestamos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            libro_id INTEGER NOT NULL,
            lector_id INTEGER NOT NULL,
            fecha_prestamo TEXT NOT NULL,
            fecha_devolucion TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'Activo',
            FOREIGN KEY(libro_id) REFERENCES libros(id),
            FOREIGN KEY(lector_id) REFERENCES lectores(id)
        );
        """
    )

    if conn.execute("SELECT COUNT(*) FROM libros").fetchone()[0] == 0:
        conn.executemany(
            "INSERT INTO libros (titulo, autor, categoria, isbn) VALUES (?, ?, ?, ?)",
            [
                ("El infinito en un junco", "Irene Vallejo", "Ensayo", "9788417860793"),
                ("La casa de los espiritus", "Isabel Allende", "Literatura", "9788401352836"),
                ("Breve historia del tiempo", "Stephen Hawking", "Ciencia", "9788498921204"),
                ("Sapiens", "Yuval Noah Harari", "Historia", "9788499926223"),
                ("Cien anos de soledad", "Gabriel Garcia Marquez", "Literatura", "9780307474728"),
            ],
        )
        conn.executemany(
            "INSERT INTO lectores (nombre, telefono, correo) VALUES (?, ?, ?)",
            [
                ("Lucia Torres", "555-0101", "lucia@example.com"),
                ("Diego Ramirez", "555-0102", "diego@example.com"),
                ("Elena Vidal", "555-0103", "elena@example.com"),
            ],
        )
        conn.commit()


def limpiar_reportes_anteriores():
    for old_file in APP_DIR.glob("reporte_biblioteca_*.xlsx"):
        old_file.unlink(missing_ok=True)
    for old_file in APP_DIR.glob("reporte_biblioteca_*.csv"):
        old_file.unlink(missing_ok=True)


def buscar_libros(conn, texto, categoria=None, estado=None):
    query = "SELECT id, titulo, autor, categoria, disponible FROM libros WHERE 1=1"
    params = []

    if texto:
        query += " AND (LOWER(titulo) LIKE ? OR LOWER(autor) LIKE ? OR LOWER(categoria) LIKE ?)"
        like = f"%{texto.lower()}%"
        params.extend([like, like, like])

    if categoria and categoria.lower() != "todos":
        query += " AND LOWER(categoria) = ?"
        params.append(categoria.lower())

    if estado and estado.lower() != "todos":
        if estado.lower() == "disponible":
            query += " AND disponible = 1"
        elif estado.lower() == "prestado":
            query += " AND disponible = 0"

    query += " ORDER BY categoria, titulo"
    return conn.execute(query, params).fetchall()


def mostrar_resultados(rows):
    if not rows:
        print("\nNo se encontraron resultados.")
        return

    print("\nRESULTADOS:")
    print("-" * 110)
    print(f"{'ID':<5} {'TITULO':<40} {'AUTOR':<30} {'CATEGORIA':<20} {'ESTADO':<12}")
    print("-" * 110)
    for row in rows:
        estado = "Disponible" if row[4] == 1 else "Prestado"
        print(f"{row[0]:<5} {row[1]:<40} {row[2]:<30} {row[3]:<20} {estado:<12}")
    print("-" * 110)


def exportar_reporte_excel(conn):
    limpiar_reportes_anteriores()
    rows = conn.execute(
        "SELECT titulo, autor, categoria, disponible FROM libros ORDER BY categoria, titulo"
    ).fetchall()

    if not rows:
        print("\nNo hay libros para exportar.")
        return None

    fecha_hoy = date.today().strftime("%Y-%m-%d")
    fecha_formateada = date.today().strftime("%d/%m/%Y")
    excel_path = APP_DIR / f"reporte_biblioteca_{fecha_hoy}.xlsx"

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Libros"

    ws.merge_cells("A1:D1")
    ws["A1"] = f"Reporte de Biblioteca - {fecha_formateada}"
    ws["A1"].font = Font(name="Arial", bold=True, size=16)
    ws["A1"].fill = PatternFill("solid", fgColor="D9EAF7")
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")

    headers = ["Titulo", "Autor", "Categoria", "Estado"]
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=3, column=col_idx, value=header)
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="4472C4")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = Border(
            left=Side(style="thin", color="D9D9D9"),
            right=Side(style="thin", color="D9D9D9"),
            top=Side(style="thin", color="D9D9D9"),
            bottom=Side(style="thin", color="D9D9D9"),
        )

    for row_idx, row in enumerate(rows, start=4):
        ws.cell(row=row_idx, column=1, value=row[0])
        ws.cell(row=row_idx, column=2, value=row[1])
        ws.cell(row=row_idx, column=3, value=row[2])
        ws.cell(row=row_idx, column=4, value="Disponible" if row[3] == 1 else "Prestado")

        for col_idx in range(1, 5):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.border = Border(
                left=Side(style="thin", color="D9D9D9"),
                right=Side(style="thin", color="D9D9D9"),
                top=Side(style="thin", color="D9D9D9"),
                bottom=Side(style="thin", color="D9D9D9"),
            )
            cell.alignment = Alignment(horizontal="left", vertical="center")

    for col_idx, width in enumerate([32, 24, 20, 14], start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    category_counts = {}
    for row in rows:
        category_counts[row[2]] = category_counts.get(row[2], 0) + 1

    ws["G2"] = "Resumen por categoria"
    ws["G2"].font = Font(name="Arial", bold=True, size=13)
    ws["G3"] = "Categoria"
    ws["H3"] = "Cantidad"
    for cell in ws[3][6:8]:
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="4472C4")
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for row_idx, (category, count) in enumerate(sorted(category_counts.items()), start=4):
        ws.cell(row=row_idx, column=7, value=category)
        ws.cell(row=row_idx, column=8, value=count)

    chart = BarChart()
    chart.type = "bar"
    chart.style = 10
    chart.title = "Libros por categoria"
    chart.y_axis.title = "Categoria"
    chart.x_axis.title = "Cantidad de libros"
    chart.height = 7
    chart.width = 12
    chart_data = Reference(ws, min_col=8, min_row=3, max_row=3 + len(category_counts))
    chart_categories = Reference(ws, min_col=7, min_row=4, max_row=3 + len(category_counts))
    chart.add_data(chart_data, titles_from_data=True)
    chart.set_categories(chart_categories)
    ws.add_chart(chart, "J2")

    ws.freeze_panes = "A4"
    ws.auto_filter.ref = f"A3:D{ws.max_row}"
    wb.save(excel_path)
    print(f"\nArchivo Excel generado: {excel_path}")
    return excel_path


def mostrar_menu():
    print("\nSISTEMA DE BIBLIOTECA")
    print("1. Buscar por libro o autor")
    print("2. Buscar por categoria")
    print("3. Ver todos los libros")
    print("4. Exportar reporte final a Excel")
    print("5. Salir")


def main():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    create_tables(conn)

    print("Bienvenido al sistema de biblioteca.")

    while True:
        mostrar_menu()
        opcion = input("Selecciona una opcion: ").strip()

        if opcion == "1":
            texto = input("Escribe el titulo o autor a buscar: ").strip()
            rows = buscar_libros(conn, texto)
            mostrar_resultados(rows)
        elif opcion == "2":
            categoria = input("Escribe la categoria: ").strip()
            rows = buscar_libros(conn, "", categoria=categoria)
            mostrar_resultados(rows)
        elif opcion == "3":
            rows = buscar_libros(conn, "")
            mostrar_resultados(rows)
        elif opcion == "4":
            exportar_reporte_excel(conn)
        elif opcion == "5":
            print("Hasta luego.")
            break
        else:
            print("Opcion invalida. Intentalo otra vez.")

        continuar = input("\nQuieres volver al menu? (s/n): ").strip().lower()
        if continuar != "s":
            print("Hasta luego.")
            break

    conn.close()


if __name__ == "__main__":
    main()
